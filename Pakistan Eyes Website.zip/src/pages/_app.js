import '@/styles/globals.css'
import '../styles/globals.css';
import Footer from '@/components/Global/Footer';
import Topbar from '@/components/Global/Topbar';
import Navbar from '@/components/Global/Navbar';
export default function App({ Component, pageProps }) {
return(
  <>
    <Topbar />
    <Navbar />
  <Component {...pageProps} />
  <Footer />
</>
)}
