import Link from "next/link";
import CategoryPost from "@/components/Home/CategoryPost";
import Gallery from "@/components/Home/gallery";
import PostItem from "@/components/Home/ItemPost";
import axios from "axios";
import { useState, useEffect } from "react";
import { BASE_URL } from "../../../api/api_config";
import { IMAGE_URL } from "../../../api/api_config";
import { useRouter } from "next/router";
import VideoCard from "@/components/Home/Video/VideoItem/VideoCard";
import Head from "next/head";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faFacebook, faTwitter,faWhatsapp } from '@fortawesome/free-brands-svg-icons';

function BlogsDetails() {
  const [posts, setPosts] = useState([]);
  
  useEffect(() => {
    axios.get(`${BASE_URL}/news`).then((res) => {
      setPosts(res.data);
    }) 
  }, []);
  const router = useRouter();
  let {id}  = router.query;
   const filteredPosts = posts.filter(post => post.id ==id); 
    const currentUrl = decodeURIComponent(`https://pakistaneyes.com/${router.asPath.replace(/ /g, '_')}`);
    console.log(currentUrl);
  return (
    
    <>  
      <div className="flex md:flex-row flex-col ">
         <div className="flex flex-col mx-4 mt-8">
        {filteredPosts.map((post, index) => (
          <div>
            <Head>
              <title>{post.title}</title>
              <meta property="og:type" content="article" />
              <meta property="og:image" content={`${IMAGE_URL}/${post.images}`} /> 
              <meta property="og:title" content={post.title.replace(/ /g, '_')} />
              <meta property="og:description" content={post.description} />
              <meta property="og:url" content={currentUrl} />
              <meta property="og:image:alt" content={post.title.replace(/ /g, '_')} />
              <meta property="og:locale" content="en_US" />
              <meta property="og:site_name" content="pakistaneyes.com/" />
              <meta name="twitter:card" content={`${IMAGE_URL}/${post.images}`} />
              <meta name="twitter:title" content={post.title.replace(/ /g, '_')} />
              <meta name="twitter:description" content={post.description} />
              <meta name="twitter:image"content={`${IMAGE_URL}/${post.images}`} /> 
            </Head>

           <div className="mx-4 md:mx-auto" key={index}>
           <div className="flex flex-col gap-4 container md:w-[65%] mx-auto my-6 md:mr-[11.5rem]">
            <div className="flex flex-row justify-between">
              <p className="text-sm mb-2 mx-2"></p>
              <div className="bg-blue-600 text-white w-fit rounded-lg px-4">
                {post.categoryID}
              </div>
            </div>
            <div>
              <img
                src={`${IMAGE_URL}/${post.images}`}
                className="w-full rounded-lg"
                alt="Image"
              />
            </div>
            <div>
              <p className="text-lg md:text-xl " > <div dangerouslySetInnerHTML={{ __html: post.description }} /></p>
            </div>
            <ul className="flex gap-4">
           <li>
             <a target="_blank" rel="" href={`https://www.facebook.com/sharer/sharer.php?u=${currentUrl}`}> <FontAwesomeIcon icon={faFacebook} className="fa-2x text-blue-600 transform hover:scale-125  transition-transform duration-300 ease-in-out" /> </a>
           </li>
           <li>
             <a
               target="_blank"
               rel="noreferrer"
               href={`https://twitter.com/share?url=${currentUrl}&text=${encodeURIComponent(post.title)}`}
             >
                 <FontAwesomeIcon icon={faTwitter} className="fa-2x  text-blue-400 transform hover:scale-125  transition-transform duration-300 ease-in-out" />
             </a>
           </li>
           <li>
             <a
                target="_blank"
               rel="noreferrer"
                href={`https://wa.me/?text=${post.title}%0A${currentUrl}`}
             >
            <FontAwesomeIcon icon={faWhatsapp} className="fa-2x  text-green-500 transform hover:scale-125  transition-transform duration-300 ease-in-out" />
             </a>
           </li>
           <li>
             <a
               target="_blank"
               rel="noreferrer"
               href={`https://www.linkedin.com/shareArticle?mini=true&url=${currentUrl}`}
             >
               <i className="fab fa-linkedin" aria-hidden="true" />
             </a>
           </li>
         </ul>
          </div>
     <div className="flex flex-col gap-10 container md:w-[60%] mx-auto my-6 md:mr-[11.5rem]">
       <div className="md:grid grid-cols-3 gap-2 md:gap-10 container mx-4  w-fit md:w-fit">
           <VideoCard
             key={index}
             thumbnail={`${IMAGE_URL}/${post.images}`}
             date={post.created_at}
             video = {post.newsvideo?`${IMAGE_URL}/${post.newsvideo}`:`${post.url}`}
             title={post.title}
             url = {post.url}
             category={post.categoryID}
           />
     </div>
   </div>
 </div>                                                          
  
  </div>
        ))}
      </div>

        <aside className="md:ml-8 md:mt-64 md:w-96">
          <div className="index ad mx-4">
            <div
              className="overlap-25"
              style={{ width: " 100%", height: "20rem" }}
            >
              <div className="text-wrapper-67">اشتہار</div>
            </div>
          </div>
          <div className="index get-latest-updates mt-5">
            <div className="bg-pink-100 py-8 relative text-center w-auto mx-4 pt-8">
              <div className="text-wrapper-71 mb-5">
                تازہ ترین اپڈیٹس حاصل کریں
              </div>
              <div className="email-adress">
                <div className="overlap-group-15">
                  <input
                    type="email"
                    className="text-wrapper-72 p-2 mb-3"
                    placeholder="آپ کا ای میل پتہ"
                  />
                </div>
              </div>
              <div className="subscribe">
                <div className="overlap-33 mx-auto pt-1">
                  <div className="text-wrapper-73">سبسکرائب</div>
                </div>
              </div>
            </div>
          </div>
          <div className=" flex flex-col mx-4 mt-8">
              {posts.map((post, index) => (
            <Link  href={`/Urdu/News/${encodeURIComponent(post.title)}/${post.id}`}>
                <PostItem
                  key={index}
                  imageSrc={`${IMAGE_URL}/${post.images}`}
                  title={post.title}
                  date={post.date}
                />
            </Link>
              ))}
          </div>
        </aside>
      </div>
        <div className="flex flex-col md:flex-row mx-4 md:mx-32 gap-10">
          {posts.slice(-4).map((post, index) => (
          
            <CategoryPost
              key={index}
             imageSrc={`${IMAGE_URL}/${post.images}`}
              category={post.categoryID}
              path ={`/Urdu/Categories/${post.categoryID}`}
              date={post.date}
              title={post.title}
              description={post.description}
            />
          ))}
        </div>
        
      <Gallery />
      
    </>
  );
}

export default BlogsDetails;
