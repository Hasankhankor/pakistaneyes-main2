export const BASE_URL = 'https://www.admin.pakistaneyes.com/public/api';
export const site_url = 'https://pakistaneyes.com';
export const IMAGE_URL = 'https://www.admin.pakistaneyes.com/public/storage/';