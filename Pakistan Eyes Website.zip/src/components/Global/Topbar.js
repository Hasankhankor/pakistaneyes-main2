"use client";
import Link from "next/link";
import Image from "next/image";
import Head from "next/head";
import Button from "./Button";
 export default function Topbar() {
  return (
    <>
   
      <nav className="hidden md:bg-white md:shadow-lg md:mb-5 md:block">
        <div className="flex justify-between px-4">
          <ul className="flex gap-8">
            <li className="items-middle pt-2 text-gray-500">
              15<sup>c</sup>{" "}
            </li>
            <li className="item-middle pt-2 text-gray-500">
              Wednesday 14 September 2023
            </li>
            <li className="bg-cyan-300 text-white py-2 px-3">Breaking News</li>
            <li className="item-middle pt-2 text-gray-500">
              This is the news title
            </li>
            <li className="item-middle pt-2 text-gray-500">social Icons</li>
          </ul>
          <ul className="flex gap-3 pt-3 text-gray-500">
            <li><Link href={'#'} > Facebook </Link></li>
            <li><Link href={'#'} > Twittor </Link></li>
            <li><Link href={'#'} > Instagram </Link></li>
            <li><Link href={'#'} > Youtube </Link></li>
          </ul>
        </div>
      </nav>
      <div className="flex flex-col md:flex-row justify-between container mx-auto md:my-6 md:pt-3">
        <div className="md:w-1/2 hidden md:block">
          <Image src="/logos/news_logo.png " width={140} height={100} />
        </div>
        <div className="md:w-1/2 bg-[url('/banners/banner1.jpg')] bg-no-repeat bg-center bg-cover md:w-4/5 max-h-32 md:block hidden">
          <div className="flex justify-between p-4 items-center">
          <div className="text-center sm:text-right mt-4">
              <Button name="ابھی خریدیں" color="bg-blue-400" />
            </div>
            <div className="text-white">
              <p>سب سے زیادہ فروخت ہونے والا بلاگ اور میگزین </p>
              <p>تھیم آف آل ٹائم</p>
              <p className="text-red-800 font-bold">تبدیلی کا تجربہ کریں!</p>
            </div>
            
          </div>
        </div>
      </div>
    </>
  );
};

