// Post13.js

import React from "react";
import Link from "next/link";
const CategoryPost = ({imageSrc,category,date,title,description,path}) => {
  return (
    <div className="post-13 ">
    <Link href={path}>
      <div className="bg-center bg-cover h-72 w-full md:w-96" style={{ backgroundImage: `url(${imageSrc})` }}>
        <div className="cricket-2">
          <div className="overlap-group-11 p-3 opacity-75 w-fit">
            <div className="text-wrapper-59">{category}</div>
          </div>
        </div>
      </div>
    </Link>
      <div className="">
        <p className="craig-bator-dec-7">
          <span className="text-wrapper-44">&nbsp;</span>
          <span className="text-wrapper-45">{date}</span>
        </p>
        <p className="w-auto text-wrapper-49 my-3 font-bold text-lg hover:text-blue-400 transition all 2s ease">
         {title}
        </p>
        <p className=" md:text-wrapper-46 leading-loose">
         {description.length > 120 && description.substring(0,100)+"..."}
        </p>
      </div>
    </div>
  );
};

export default CategoryPost;
