import SpotlightCard from "./SpotlightCard"
const Spotlight = () => {
  return (
        <div className="mx-4 md:mx-24 flex flex-col md:flex-row justify-center gap-8 md:gap-28 ">
        <SpotlightCard />
        </div>

  );
};

export default Spotlight
