import Image from "next/image";

const PostItem = ({ imageSrc, title, date }) => {
  return (
    <div className="post-6 flex flex-col md:flex-row items-center gap-4 mb-3 md:text-left text-center text-2xl ">
      <img
        className="image md:max-w-[25%]  w-full"
        alt="Image"
        src={imageSrc}
      />
      <div className="leading-none text-black">
        <p className="craig-bator-dec-5 flex">
          <span className="text-wrapper-44">&nbsp;</span>
          <span className="text-sm">{date}</span>
        </p>
        <p className="leading-2 md:text-right text-center text-sm font-bold hover:text-blue-400 transition-all 2s ease">
          {title}
        </p>
      </div>
    </div>
  );
};

export default PostItem;
